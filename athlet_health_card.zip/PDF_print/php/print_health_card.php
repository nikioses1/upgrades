<?php include ("../../php/config.php"); ?>
<?php
date_default_timezone_set("Europe/Athens");
$GreekMonths = array('ΙΑΝΟΥΑΡΙΟΥ','ΦΕΒΡΟΥΑΡΙΟΥ','ΜΑΡΤΙΟΥ','ΑΠΡΙΛΙΟΥ','ΜΑΪΟΥ','ΙΟΥΝΙΟΥ','ΙΟΥΛΙΟΥ','ΑΥΓΟΥΣΤΟΥ','ΣΕΠΤΕΜΒΡΙΟΥ','ΟΚΤΩΒΡΙΟΥ','ΝΟΕΜΒΡΙΟΥ','ΔΕΚΕΜΒΡΙΟΥ');
$GreekDays = array('Κυριακή','Δευτέρα','Τρίτη','Τετάρτη','Πέμπτη','Παρασκευή','Σάββατο');

$err_msg = $certificate = null;

// $_GET the $cert_id
$cert_id = isset($_GET['CERT']) ? $_GET['CERT'] : null;

try{
	$query = "
	SELECT
	medical_certificates.id, medical_certificates.patient_id, medical_certificates.cert_date, medical_certificates.cert_json
	FROM medical_certificates
	WHERE medical_certificates.id = :cert_id AND medical_certificates.cert_kind = 5
	;
	";

	// Use prepared statements to avoid SQL injection.
	$stmt = $conn->prepare($query);

	// Check if prepare was successful.
	if ($stmt === false) {
		throw new Exception("Prepare statement failed: ".$conn->error, 100);
	}
	
	// Bind parameters.
	if($stmt->bindParam(':cert_id', $cert_id, PDO::PARAM_INT) === false){
		throw new Exception("Statement bind error", 101);
	}
	// Execute the statement.
	if($stmt->execute() === false){
		throw new Exception("Statement execution error", 102);
	}
	// Check if data was found after the statement was executed.
	if($stmt->rowCount() === 0){
		throw new Exception("No records found", 400);
	}
	// Get results into "$result" array as objects (use this if you expect multiple result packets).
	#$result = $stmt->fetchAll(PDO::FETCH_OBJ);
	// Get results into the "$result" object (use this if you expect only one result packet).
	$result = $stmt->fetch(PDO::FETCH_OBJ);
	
	$certificate =  json_decode($result->cert_json);
	$certificate->cert_date = $result->cert_date;
}
catch(Exception $e){
	// If no records are found using the first query, try an alternate query.
	if($e->getCode() === 400){
		$query_old = "
		SELECT 
		patient.PAT_NAME, patient.PAT_SURNAME, patient.PAT_FATHERS_NAME,patient.PAT_MOTHERS_NAME, patient.PAT_BIRTHDAY, 
		RIGHT(CONCAT('00000000000', patient.PAT_AMKA), 11) as PAT_AMKA,
		patient.PAT_TEL, patient.PAT_EMAIL,
		patient.PAT_ADDRESS, postal_codes_city.zip_code, postal_codes_city.zip_city,
		health_card.HC_Kind, health_card.HC_exam_date AS cert_date, health_card.json_card_data AS cert_json
		FROM patient
		INNER JOIN health_card ON patient.PAT_ID = health_card.PAT_ID
		INNER JOIN postal_codes_city ON patient.zipID = postal_codes_city.zip_id
		WHERE health_card.HC_ID = :cert_id
		;
		";

		// Use prepared statements to avoid SQL injection.
		$stmt = $conn->prepare($query_old);

		// Check if prepare was successful.
		if ($stmt === false) {
			throw new Exception("Prepare statement failed: ".$conn->error, 100);
		}
		
		// Bind parameters.
		if($stmt->bindParam(':cert_id', $cert_id, PDO::PARAM_INT) === false){
			throw new Exception("Statement bind error", 101);
		}
		// Execute the statement.
		if($stmt->execute() === false){
			throw new Exception("Statement execution error", 102);
		}
		// Check if data was found after the statement was executed.
		if($stmt->rowCount() === 0){
			throw new Exception("No records found", 400);
		}
		// Get results into "$result" array as objects (use this if you expect multiple result packets).
		#$result = $stmt->fetchAll(PDO::FETCH_OBJ);
		// Get results into the "$result" object (use this if you expect only one result packet).
		$result = $stmt->fetch(PDO::FETCH_OBJ);
		
		$certificate =  json_decode($result->cert_json);
		
	}else{
		$err_msg = $e->getMessage();
		die($e->getMessage()." ".$e->getCode());
	}
}
finally{
    // Close the statement to save resources.
    if(isset($stmt)){
        $stmt = null;
    }
}

if($err_msg == null){
	
	$selected_federation 	= $certificate->HC_Kind;
	//ΟΝΟΜΑΤΕΠΩΝΥΜΟ
	$FULL_NAME = $certificate->PAT_NAME.' '.$certificate->PAT_SURNAME;
	//ΟΝΟΜΑ
	$NAME 	= property_exists($certificate, "PAT_NAME") ? $certificate->PAT_NAME : null;
	//ΕΠΩΝΥΜΟ
	$SNAME 	= property_exists($certificate, "PAT_SURNAME") ? $certificate->PAT_SURNAME : null;
	//ΟΝΟΜΑΤΕΠΩΝΥΜΟ
	$FULL_NAME = $NAME.' '.$SNAME;	
	//ΟΝΟΜΑ ΠΑΤΕΡΑ
	$FNAME 	= property_exists($certificate, "PAT_FATHERS_NAME") ? $certificate->PAT_FATHERS_NAME : null;
	//ΟΝΟΜΑ ΜΗΤΕΡΑΣ
	$MNAME 	= property_exists($certificate, "PAT_MOTHERS_NAME") ? $certificate->PAT_MOTHERS_NAME : null;
	//ΗΜΕΡΟΜΗΝΙΑ ΓΕΝΝΗΣΗΣ
	$BIRTHDAY =  property_exists($certificate, "PAT_BIRTHDAY") ? date("d", strtotime($certificate->PAT_BIRTHDAY)).' '.$GreekMonths[date("n", strtotime($certificate->PAT_BIRTHDAY)) -1].' '.date("Y", strtotime($certificate->PAT_BIRTHDAY)) : null;
	//A.M.K.A.
	$AMKA 	= property_exists($certificate, "PAT_AMKA") ? $certificate->PAT_AMKA : null;
	//ΔΙΕΥΘΥΝΣΗ ΑΘΛΗΤΗ
	$ADDRESS 	= property_exists($certificate, "PAT_ADDRESS") ? $certificate->PAT_ADDRESS : null;
	$CITY 	= property_exists($certificate, "zip_city") ? $certificate->zip_city : null;
	$POST_CODE 	= property_exists($certificate, "zip_code") ? $certificate->zip_code : null;
	//ΤΗΛΕΦΩΝΟ
	$PHONE 	= property_exists($certificate, "PAT_TEL") ? $certificate->PAT_TEL : null;

	//email
	$EMAIL 	= property_exists($certificate, "PAT_EMAIL") ? $certificate->PAT_EMAIL : null;
	
	//Ημερομηνία έκδοσης της Κάρτας Υγείας αθλητή 
	$EXAM_DATE 			= date("d", strtotime($certificate->cert_date)).' '.$GreekMonths[date("n", strtotime($certificate->cert_date)) -1].' '.date("Y", strtotime($certificate->cert_date)); //date("d/m/Y", strtotime($HC_exam_date));
	$EXAM_DATE_DAY 		= date("d", strtotime($certificate->cert_date));
	$EXAM_DATE_MONTH 	= date("m", strtotime($certificate->cert_date));
	$EXAM_DATE_YEAR 	= date("Y", strtotime($certificate->cert_date));
	
	if(!empty($certificate)){
		$federation_register_number = $certificate->fed_register_numb;
	}else{
		$federation_register_number = null;
	}
	
	$DR_NAME = "ΝΙΚΟΛΑΟΣ";
	$DR_SURNAME = "ΚΙΟΣΕΣ";
	$DR_SPECIALITY = "ΓΕΝΙΚΟΣ ΟΙΚΟΓΕΝΕΙΑΚΟΣ ΙΑΤΡΟΣ";
	$DR_PHONE = "25940 31322";

}else{
	$NAME = $SNAME = $FNAME = $BIRTHDAY = $AMKA = $EXAM_DATE = $EXAM_DATE_DAY = $EXAM_DATE_MONTH = $EXAM_DATE_YEAR = $selected_federation = $federation_register_number = null;
}

/*
 *
 */

$dir = "../templates/federation_cards/";
$dir_content = array();

foreach(scandir($dir) as $key => $dir_name){
	array_push($dir_content, $dir_name);
}
$dir_content = array_diff($dir_content, [".", ".."]);
sort($dir_content);

foreach($dir_content as $x => $filename){
	$pieces = explode('_', $filename);
	$federation_pdf_root[$pieces[0]] = $dir.''.$filename;
	$federation_name_array[$pieces[0]] = basename($pieces[3],".pdf");
}

//(1) ΕΛΛΗΝΙΚΗ ΠΟΔΟΣΦΑΙΡΙΚΗ ΟΜΟΣΠΟΝΔΙΑ (Ε.Π.Ο.)
$federation_name = "epo-old";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>10,'y'=>5,'w'=>275);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[1];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($federation_register_number, $NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('194', '191', '191', '191', '191', '191', '181', '192', '206');
${$federation_name.'_cell_y_position'}	= array('51.5', '84', '91.5', '99', '106', '113', '157.5', '157.5', '157.5');
${$federation_name.'_cell_width'}		= array('49', '84', '84', '84', '84', '84', '10', '13', '13');
${$federation_name.'_cell_align'}		= array('C', 'L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

$federation_name = "epo";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>10,'y'=>5,'w'=>275);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[101];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($federation_register_number, $NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE);
${$federation_name.'_cell_x_position'}	= array('187', '180', '180', '180', '180', '180', '145');
${$federation_name.'_cell_y_position'}	= array('12', '32', '48', '64', '80.5', '96.5', '176');
${$federation_name.'_cell_width'}		= array('49', '58', '58', '58', '58', '58', '52');
${$federation_name.'_cell_align'}		= array('C', 'L', 'L', 'L', 'L', 'L', 'C');

//(2) ΣΥΝΔΕΣΜΟΣ ΕΛΛΗΝΙΚΩΝ ΓΥΜΝΑΣΤΙΚΩΝ ΑΘΛΗΤΙΚΩΝ ΣΩΜΑΤΕΙΩΝ (Σ.Ε.Γ.Α.Σ.)
$federation_name = "segas";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[2];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('60', '60', '60', '60', '60', '65', '75', '85');
${$federation_name.'_cell_y_position'} 	= array('123', '130', '136.5', '143.5', '150.5', '176.5', '176.5', '176.5');
${$federation_name.'_cell_width'}		= array('69', '69', '69', '69', '69', '8', '9', '16');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

//(3) ΚΟΛΥΜΒΗΤΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΕΛΛΑΔΑΣ (Κ.Ο.Ε.)
$federation_name = "koe";

${$federation_name.'_page_orientation'}	= 'P';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>17,'w'=>185);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[3];
${$federation_name.'_number_of_pages'}	= 2;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE);
${$federation_name.'_cell_x_position'}	= array('52', '52', '52', '52', '116', '42');
${$federation_name.'_cell_y_position'} 	= array('130', '122', '138', '146', '146', '182');
${$federation_name.'_cell_width'}		= array('124', '124', '124', '53', '60', '60');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'C', 'C', 'C');

//(4) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΚΑΛΑΘΟΣΦΑΙΡΙΣΗΣ (Ε.Ο.Κ.)
$federation_name = "eok";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[4];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('191', '191', '191', '191', '191', '188', '199', '212');
${$federation_name.'_cell_y_position'}	= array('104', '112.5', '120.5', '128.5', '136.5', '162.5', '162.5', '162.5');
${$federation_name.'_cell_width'}		= array('72', '72', '72', '72', '72', '9', '11', '10');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

//(5) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΤΑΕΚΒΟΝΤΟ (ΕΛ.Ο.Τ.)
$federation_name = "elot";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[5];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('186', '186', '186', '186', '186', '176.5', '186', '195');
${$federation_name.'_cell_y_position'}	= array('90.5', '100', '109.5', '119', '128.5', '162.5', '162.5', '162.5');
${$federation_name.'_cell_width'}		= array('50', '50', '50', '50', '50', '8', '8', '10');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

//(6) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΥΠΟΒΡΥΧΙΑΣ ΔΡΑΣΤΗΡΙΟΤΟΤΗΤΑΣ & ΑΘΛΗΤΙΚΗΣ ΑΛΙΕΙΑΣ (Ε.Ο.Υ.Δ.Α.)
$federation_name = "eoyda";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[6];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('185', '185', '185', '185', '185', '173', '185', '203');
${$federation_name.'_cell_y_position'}	= array('111', '118', '125.5', '132.5', '139.5', '171', '171', '171');
${$federation_name.'_cell_width'}		= array('78', '78', '78', '78', '78', '12', '18', '14');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

//(7) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΠΕΤΟΣΦΑΙΡΙΣΗΣ (Ε.Ο.Π.)
$federation_name = "hvf";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[7];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($NAME , $SNAME, $FNAME, $BIRTHDAY, $AMKA, $EXAM_DATE_DAY, $EXAM_DATE_MONTH, $EXAM_DATE_YEAR);
${$federation_name.'_cell_x_position'}	= array('194', '194', '194', '194', '194', '190', '199', '211');
${$federation_name.'_cell_y_position'}	= array('110', '118.5', '127', '135.5', '144', '169', '169', '169');
${$federation_name.'_cell_width'}		= array('78', '78', '78', '78', '78', '9', '12', '10');
${$federation_name.'_cell_align'}		= array('L', 'L', 'L', 'L', 'L', 'C', 'C', 'C');

//(9) ΕΛΛΗΝΙΚΗ ΙΣΤΙΟΠΛΟΪΚΗ ΟΜΟΣΠΟΝΔΙΑ  (Ε.Ι.Ο.)
$federation_name = "hsf";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[9];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(11) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΑΡΣΗΣ ΒΑΡΩΝ (Ε.Ο.Α.Β.)
$federation_name = "eoav";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[11];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(12) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΓΚΟΛΦ (Ε.Ο.Γ.)
$federation_name = "hgf";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[12];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(13) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΙΠΠΑΣΙΑΣ (Ε.Ο.Ι.)
$federation_name = "hef";

${$federation_name.'_page_orientation'}	= 'P';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>210);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[13];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array($FULL_NAME, $FNAME, $MNAME, $BIRTHDAY, $AMKA, $ADDRESS, $CITY, $POST_CODE, $PHONE, $EMAIL, $DR_SURNAME, $DR_NAME, $DR_SPECIALITY, $DR_PHONE, $EXAM_DATE);
${$federation_name.'_cell_x_position'}	= array('61.5', '61.5', '143', '61.5', '61.5', '89', '89', '157', '61.5', '143.5', '78', '78', '78', '78', '19');
${$federation_name.'_cell_y_position'}	= array('77.5', '84', '84', '90.5', '97', '104', '110.5', '110.5', '117', '117', '136.5', '143', '149.5', '157', '189');
${$federation_name.'_cell_width'}		= array('129.5', '50', '48', '50', '129.5','54', '54', '34', '50', '47.5', '112.5', '112.5', '112.5', '112.5', '47');
${$federation_name.'_cell_align'}		= array('C', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'C');

//(14) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΚΑΝΟΕ-ΚΑΓΙΑΚ (Ε.Ο.Κ.Κ.)
$federation_name = "eok-k";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[14];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(15) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΚΑΡΑΤΕ (ΕΛ.Ο.Κ.)
$federation_name = "elok";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[15];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(17) ΕΛΛΗΝΙΚΗ ΟΜΟΣΠΟΝΔΙΑ ΞΙΦΑΣΚΙΑΣ (Ε.Ο.Ξ.)
$federation_name = "hff";

${$federation_name.'_page_orientation'}	= 'P';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>200);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[17];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

//(33) ΑΘΛΗΤΙΚΗ ΟΜΟΣΠΟΝΔΙΑ TAEKWON-DO ΕΛΛΑΔΟΣ (Α.Ο.Τ.Ε.)
$federation_name = "aote";

${$federation_name.'_page_orientation'}	= 'L';
${$federation_name.'_pdf_on_page'}		= array('x'=>0,'y'=>0,'w'=>290);
${$federation_name.'_pdf_template'} 	= $federation_pdf_root[33];
${$federation_name.'_number_of_pages'}	= 1;
${$federation_name.'_cell_values'}		= array();
${$federation_name.'_cell_x_position'}	= array();
${$federation_name.'_cell_y_position'}	= array();
${$federation_name.'_cell_width'}		= array();
${$federation_name.'_cell_align'}		= array();

class federation_card{
	//public properties
	public $page_orientation;
	public $pdf_on_page		= array();
	public $pdf_template;
	public $number_of_pages;
	
	public $cell_values 	= array();
	public $cell_x_position = array();
	public $cell_y_position	= array();
	public $cell_width		= array();
	public $cell_align		= array();
}

if(array_key_exists($selected_federation, $federation_name_array)){
  $federation = $federation_name_array[$selected_federation];
}else{
	$federation = null;
	if($err_msg != null){
		$err_msg = $err_msg;
	}else{
		$err_msg = 'The selected federation does not exist in the list';
	}
}

if($federation != null){
	$Health_card = new federation_card();
	
	$Health_card->page_orientation	= ${$federation.'_page_orientation'};
	$Health_card->pdf_on_page		= ${$federation.'_pdf_on_page'};
	$Health_card->pdf_template 		= ${$federation.'_pdf_template'};
	$Health_card->number_of_pages	= ${$federation.'_number_of_pages'};
	
	$Health_card->cell_values		= ${$federation.'_cell_values'};
	$Health_card->cell_x_position	= ${$federation.'_cell_x_position'};
	$Health_card->cell_y_position	= ${$federation.'_cell_y_position'};
	$Health_card->cell_width		= ${$federation.'_cell_width'};
	$Health_card->cell_align		= ${$federation.'_cell_align'};
}

/*
 *
 */

use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader;

define('FPDF_FONTPATH','../fPDF/font');

require_once('../fPDF/fpdf.php');
require_once('../FPDI/src/autoload.php');

if($err_msg == null){
	$pdf = new Fpdi($Health_card->page_orientation,'mm','A4');
	$pdf->AddFont('Ubuntu','','Ubuntu-R.php');
	$pageCount = $pdf->setSourceFile($Health_card->pdf_template);
	for($x=0;$x<$Health_card->number_of_pages;$x++){
		$a=$x+1;
		$pageId[$x] = $pdf->importPage($a, PdfReader\PageBoundaries::MEDIA_BOX);
	}

	$pdf->addPage();
	$pdf->useImportedPage($pageId[0], $Health_card->pdf_on_page['x'], $Health_card->pdf_on_page['y'], $Health_card->pdf_on_page['w']);
	$pdf->SetFont('Ubuntu','',10);

	foreach($Health_card->cell_values as $x => $value){
		$pdf->setXY($Health_card->cell_x_position[$x],$Health_card->cell_y_position[$x]);
		$pdf->Cell($Health_card->cell_width[$x],5,iconv('UTF-8', 'CP1253',$Health_card->cell_values[$x]),0,1,$Health_card->cell_align[$x]);
	}

	if($Health_card->number_of_pages >1){
		for($x=1;$x<$Health_card->number_of_pages;$x++){
			$pdf->addPage();
			$pdf->useImportedPage($pageId[$x], $Health_card->pdf_on_page['x'], $Health_card->pdf_on_page['y'], $Health_card->pdf_on_page['w']);
		}
	}
}else{
	$pdf = new Fpdi('P','mm','A4');
	$pdf->AddFont('Ubuntu','','Ubuntu-R.php');
	$pdf->addPage();
	$pdf->SetFont('Ubuntu','',12);
	
	$pdf->MultiCell(190,5,iconv('UTF-8', 'CP1253',$err_msg),0,'C',false);
	
}

$pdf->Output();
?>